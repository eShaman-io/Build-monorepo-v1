"use client";
import { ApolloProvider } from "@apollo/client";
import { apollo } from "@/lib/apollo-client";

export default function Providers({ children }: { children: React.ReactNode }) {
  return <ApolloProvider client={apollo}>{children}</ApolloProvider>;
}
