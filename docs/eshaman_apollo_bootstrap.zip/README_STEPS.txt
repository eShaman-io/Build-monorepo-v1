eShaman Apollo Bootstrap – Quick Use

1) In your Next.js project (the folder with package.json), drop these files so paths look like:
   src/lib/apollo-client.ts
   src/app/providers.tsx
   src/app/layout.tsx

2) Install deps:
   npm i @apollo/client graphql

3) Create `.env.local` in your project root and set:
   NEXT_PUBLIC_GRAPHQL_URI=https://your-remote-graphql.com/graphql
   # or, if you later add a local API route:
   # NEXT_PUBLIC_GRAPHQL_URI=/api/graphql

4) Start dev:
   npm run dev

5) If your layout.tsx already exists and you don't want to overwrite it,
   just copy this wrapper into your existing layout:
     import Providers from "./providers";
     ...
     <body>
       <Providers>{children}</Providers>
     </body>

6) Later, you can add a test page that runs a query, or hook your real pages/components to Apollo.
