export const theme = {
  colors: {
    primary: "#5CE1E6",
    primary700: "#0EA5A6",
    secondary: "#7C3AED",
    accent: "#22D3EE",
    bg: "#F8FAFC",
    fg: "#0B1020"
  },
  motion: { durations: { xs: 160, sm: 240, md: 400, lg: 600 }, pressScale: 0.96 }
};