import Hero from "./components/Hero";
import "./theme.css";
import "./globals.css";

export default function Page(){
  return (<main><Hero /></main>);
}